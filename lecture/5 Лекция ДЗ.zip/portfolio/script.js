// ===== Фильтрация проектов =====
const filterButtons = document.querySelectorAll('.filter-btn');
const cards = document.querySelectorAll('.card');

filterButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    // Активная кнопка
    filterButtons.forEach((b) => b.classList.remove('is-active'));
    btn.classList.add('is-active');

    const filter = btn.dataset.filter;

    cards.forEach((card) => {
      const match = filter === 'all' || card.dataset.category === filter;
      card.classList.toggle('is-hidden', !match);

      // Перезапуск анимации появления
      if (match) {
        card.style.animation = 'none';
        void card.offsetWidth; // reflow
        card.style.animation = '';
      }
    });
  });
});

// ===== Lightbox =====
const lightbox = document.getElementById('lightbox');
const lightboxImg = document.getElementById('lightboxImg');
const lightboxClose = document.getElementById('lightboxClose');

function openLightbox(src, alt) {
  lightboxImg.src = src;
  lightboxImg.alt = alt || '';
  lightbox.hidden = false;
  document.body.style.overflow = 'hidden';
  lightboxClose.focus();
}

function closeLightbox() {
  lightbox.hidden = true;
  lightboxImg.src = '';
  document.body.style.overflow = '';
}

cards.forEach((card) => {
  card.addEventListener('click', () => {
    const img = card.querySelector('.card__img');
    openLightbox(img.src, img.alt);
  });

  // Доступность: открытие с клавиатуры
  card.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      const img = card.querySelector('.card__img');
      openLightbox(img.src, img.alt);
    }
  });
});

lightboxClose.addEventListener('click', closeLightbox);

// Закрытие по клику на фон
lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) closeLightbox();
});

// Закрытие по Escape
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && !lightbox.hidden) closeLightbox();
});